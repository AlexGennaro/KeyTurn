// Netlify sends the client back here after they approve. We swap the code for a token
// and keep it in a secure, HttpOnly cookie for this browser session only.
const { parseCookies, cookie, redirectUri } = require('../lib/util');

exports.handler = async (event) => {
  const { code, state, error } = event.queryStringParameters || {};
  const saved = parseCookies(event.headers.cookie || event.headers.Cookie).oauth_state;

  const back = (query) => ({
    statusCode: 302,
    headers: { Location: `/?${query}#launch` },
    multiValueHeaders: { 'Set-Cookie': [cookie('oauth_state', '', 0)] },
    body: '',
  });

  if (error) return back('auth=denied');
  if (!code || !state || state !== saved) return back('auth=failed');

  const res = await fetch('https://api.netlify.com/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      client_id: process.env.NETLIFY_CLIENT_ID,
      client_secret: process.env.NETLIFY_CLIENT_SECRET,
      redirect_uri: redirectUri(event),
    }),
  });
  if (!res.ok) return back('auth=failed');
  const { access_token } = await res.json();

  return {
    statusCode: 302,
    headers: { Location: '/?auth=ok#launch' },
    multiValueHeaders: {
      'Set-Cookie': [cookie('oauth_state', '', 0), cookie('nf_token', access_token, 60 * 60 * 8)],
    },
    body: '',
  };
};
