// Looks up the client's DNS to see whether the two records are in place,
// and asks Netlify to issue the HTTPS certificate once they are.
const dns = require('dns').promises;
const { json, getToken, netlify, cleanDomain, DOMAIN_RE, NETLIFY_APEX_IP } = require('../lib/util');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  const token = getToken(event);
  if (!token) return json(401, { error: 'Connect a Netlify account first.' });

  let payload;
  try { payload = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Bad request.' }); }
  const domain = cleanDomain(payload.domain);
  const siteId = String(payload.siteId || '');
  if (!DOMAIN_RE.test(domain) || !siteId) return json(400, { error: 'Missing site or domain.' });

  let site;
  try { site = await netlify(token, `/sites/${siteId}`); }
  catch (e) { return json(404, { error: 'Could not find that site in this Netlify account.' }); }

  const apex = await dns.resolve4(domain).catch(() => []);
  const www = await dns.resolveCname(`www.${domain}`).catch(() => []);

  const apexOk = apex.includes(NETLIFY_APEX_IP);
  const wwwOk = www.some((v) => v.replace(/\.$/, '') === site.default_domain);

  let https = 'waiting';
  if (apexOk || wwwOk) {
    try {
      await netlify(token, `/sites/${siteId}/ssl`, { method: 'POST' });
      https = 'requested';
    } catch (e) {
      // Netlify also retries on its own, so this isn't fatal.
      https = 'pending';
    }
  }

  return json(200, {
    apex: { ok: apexOk, found: apex },
    www: { ok: wwwOk, found: www },
    https,
  });
};
