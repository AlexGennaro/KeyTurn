// Tells the page which Netlify account is connected, so you can confirm it's the client's.
const { json, getToken, netlify } = require('../lib/util');

exports.handler = async (event) => {
  const token = getToken(event);
  if (!token) return json(401, { connected: false });
  try {
    const user = await netlify(token, '/user');
    return json(200, { connected: true, email: user.email, name: user.full_name || '' });
  } catch (e) {
    return json(401, { connected: false });
  }
};
