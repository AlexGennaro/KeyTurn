// Sends the client to Netlify to sign in and approve access to their own account.
const crypto = require('crypto');
const { cookie, redirectUri, isConfigured } = require('../lib/util');

exports.handler = async (event) => {
  if (!isConfigured()) return { statusCode: 302, headers: { Location: '/setup.html' }, body: '' };
  const state = crypto.randomBytes(16).toString('hex');
  const params = new URLSearchParams({
    client_id: process.env.NETLIFY_CLIENT_ID,
    response_type: 'code',
    redirect_uri: redirectUri(event),
    state,
  });
  return {
    statusCode: 302,
    headers: { Location: `https://app.netlify.com/authorize?${params}` },
    multiValueHeaders: { 'Set-Cookie': [cookie('oauth_state', state, 600)] },
    body: '',
  };
};
