// Public, read-only: the client's order tracker. Needs the private token from their tracking link.
// Returns only what the client should see: business, plan, stage, dates and their preview link.
const { json } = require('../lib/util');
const { stores } = require('../lib/store');
const { STAGES } = require('../lib/track');

exports.handler = async (event) => {
  const t = String((event.queryStringParameters || {}).t || '');
  if (!/^[A-Za-z0-9_-]{20,64}$/.test(t)) return json(404, { error: 'This tracking link isn\'t valid. Check the link in your email.' });
  const s = stores(event);
  const ref = await s.tracks.get(t, { type: 'json' });
  const r = ref && (await s.requests.get(ref.id, { type: 'json' }));
  if (!r || r.trackToken !== t) return json(404, { error: 'This tracking link isn\'t valid. Check the link in your email.' });

  const when = {};
  (r.history || []).forEach((h) => { when[h.status] = h.at; });
  if (!when.new && r.submittedAt) when.new = r.submittedAt;
  const order = STAGES.map(([k]) => k);
  const reached = r.status === 'closed' ? -1 : order.indexOf(r.status);
  return json(200, {
    business: r.business, planName: r.planName, firstName: String(r.name || '').trim().split(/\s+/)[0],
    status: r.status, closed: r.status === 'closed',
    stages: STAGES.map(([k, label], i) => ({ key: k, label, done: i <= reached, current: i === reached, at: when[k] || null })),
    previewUrl: ['preview_sent', 'paid', 'live'].includes(r.status) && r.previewUrl ? r.previewUrl : null,
    site: r.status === 'live' && r.domain ? 'https://' + String(r.domain).replace(/^https?:\/\//, '').replace(/\/.*$/, '') : null,
    updatedAt: r.updatedAt || r.submittedAt || r.createdAt,
  });
};
