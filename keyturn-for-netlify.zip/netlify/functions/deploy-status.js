// Reports whether an upload has finished processing, so the page only says "live" when it is.
const { json, getToken, netlify } = require('../lib/util');

exports.handler = async (event) => {
  const token = getToken(event);
  if (!token) return json(401, { error: 'signin' });
  const id = (event.queryStringParameters || {}).id;
  if (!id || !/^[a-z0-9]+$/i.test(id)) return json(400, { error: 'Missing deploy id.' });
  try {
    const d = await netlify(token, `/deploys/${id}`);
    return json(200, { state: d.state, error: d.error_message || null });
  } catch (e) {
    return json(e.status === 401 ? 401 : 502, { error: e.status === 401 ? 'signin' : e.message });
  }
};
