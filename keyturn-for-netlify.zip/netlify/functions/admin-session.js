// Tells the admin page whether sign-in is set up and whether this browser is signed in.
const { json } = require('../lib/util');
const { adminConfigured, isAdmin } = require('../lib/admin');

exports.handler = async (event) => json(200, { configured: adminConfigured(), signedIn: isAdmin(event) });
