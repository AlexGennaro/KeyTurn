// Admin only: returns one uploaded image. Locked down so an uploaded file can never run code on this site.
const { stores } = require('../lib/store');
const { isAdmin } = require('../lib/admin');

exports.handler = async (event) => {
  if (!isAdmin(event)) return { statusCode: 401, body: 'Sign in first.' };
  const key = String((event.queryStringParameters || {}).key || '');
  if (!/^[A-Za-z0-9]+\/\d{1,2}$/.test(key)) return { statusCode: 400, body: 'Bad file name.' };
  const s = stores(event);
  const hit = await s.uploads.getWithMetadata(key, { type: 'arrayBuffer' });
  if (!hit) return { statusCode: 404, body: 'Not found.' };
  const { name = 'image', type = 'application/octet-stream' } = hit.metadata || {};
  const download = (event.queryStringParameters || {}).download || type === 'image/svg+xml';
  return {
    statusCode: 200,
    isBase64Encoded: true,
    body: Buffer.from(hit.data).toString('base64'),
    headers: {
      'Content-Type': type,
      'Content-Disposition': `${download ? 'attachment' : 'inline'}; filename="${String(name).replace(/"/g, '')}"`,
      'Content-Security-Policy': "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox",
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'private, no-store',
    },
  };
};
