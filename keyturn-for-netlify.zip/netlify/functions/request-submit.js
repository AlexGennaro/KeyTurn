// Step 3: marks the request as sent and emails the Keyturn team (NOTIFY_EMAIL, TryKeyTurn@gmail.com by default).
const { json } = require('../lib/util');
const { stores, log } = require('../lib/store');
const { checkUploadToken, sameOrigin } = require('../lib/admin');
const { send, esc, NOTIFY_EMAIL } = require('../lib/mail');
const { ensureTracker, recordStatus, trackUrl, sendClientEmail } = require('../lib/track');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  if (!sameOrigin(event)) return json(403, { error: 'Requests must come from this site.' });
  let b;
  try { b = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Something went wrong. Please try again.' }); }
  const id = String(b.id || ''), expires = parseInt(b.expires, 10);
  if (!checkUploadToken(id, expires, b.token)) return json(403, { error: 'This form has expired. Please send it again.' });

  const s = stores(event);
  const r = await s.requests.get(id, { type: 'json' });
  if (!r) return json(404, { error: 'Request not found.' });
  if (r.status !== 'uploading') return json(200, { ok: true, trackUrl: r.trackToken ? trackUrl(event, r.trackToken) : null }); // already sent
  r.status = 'new';
  r.submittedAt = new Date().toISOString();
  recordStatus(r, 'new');
  await ensureTracker(s, r);
  await s.requests.setJSON(id, r);
  const track = trackUrl(event, r.trackToken);
  await log(s, 'visitor', 'Sent a request', `${r.planName} · ${r.business} · ${r.files.length} image(s)`);

  const host = event.headers['x-forwarded-host'] || event.headers.host;
  const adminUrl = `https://${host}/admin/#r=${encodeURIComponent(id)}`;
  const rows = [
    ['Plan', r.planName], ['Name', r.name], ['Business', r.business], ['Email', r.email], ['Phone', r.phone || '—'],
    ['Web address', r.domain || '—'], ['What the business does', r.about], ['What the website should include', r.wants],
    ['Colors and style', r.style || '—'], ['Websites they like', r.examples || '—'], ['Images', `${r.files.length} uploaded`],
    ['Client\'s tracking link', track],
  ];
  const text = `New ${r.planName} request from ${r.business}\n\n` + rows.map(([k, v]) => `${k}: ${v}`).join('\n') + `\n\nOpen it in the admin page: ${adminUrl}\n`;
  const html = `<h2 style="font-family:Georgia,serif">New ${esc(r.planName)} request</h2><table cellpadding="6" style="font-family:Arial,sans-serif;font-size:14px;border-collapse:collapse">` +
    rows.map(([k, v]) => `<tr><td style="color:#666;vertical-align:top;white-space:nowrap">${esc(k)}</td><td style="white-space:pre-wrap">${esc(v)}</td></tr>`).join('') +
    `</table><p style="font-family:Arial,sans-serif"><a href="${esc(adminUrl)}">Open the request in the admin page</a> to see the images.</p>`;
  const sent = await send({ to: NOTIFY_EMAIL, subject: `New ${r.planName} request: ${r.business}`, text, html, replyTo: r.email });
  if (!sent.ok) await log(s, 'server', 'Notification email not sent', sent.skipped || sent.error);
  const mine = await sendClientEmail('received', r, event);
  await log(s, 'server', mine.ok ? 'Confirmation emailed to client' : 'Client confirmation not sent', mine.ok ? r.email : (mine.skipped || mine.error));
  return json(200, { ok: true, trackUrl: track, emailed: !!mine.ok });
};
