// Step 2: adds one image (logo or photo) to a request. The page sends images one at a time,
// already resized in the browser, so each stays well under Netlify's request size limit.
const { json } = require('../lib/util');
const { stores } = require('../lib/store');
const { checkUploadToken, sameOrigin } = require('../lib/admin');

const TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'];
const MAX_BYTES = 4 * 1024 * 1024;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  if (!sameOrigin(event)) return json(403, { error: 'Uploads must come from this site.' });
  const q = event.queryStringParameters || {};
  const id = String(q.id || ''), expires = parseInt(q.expires, 10);
  if (!checkUploadToken(id, expires, q.token)) return json(403, { error: 'This upload link has expired. Please send the form again.' });

  const type = String(event.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  if (!TYPES.includes(type)) return json(400, { error: 'Only images can be uploaded (JPG, PNG, WebP, GIF or SVG).' });
  const body = Buffer.from(event.body || '', event.isBase64Encoded ? 'base64' : 'utf8');
  if (!body.length) return json(400, { error: 'That image was empty.' });
  if (body.length > MAX_BYTES) return json(400, { error: 'That image is over 4 MB.' });

  const s = stores(event);
  const r = await s.requests.get(id, { type: 'json' });
  if (!r || r.status !== 'uploading') return json(409, { error: 'This request is already sent.' });
  if (r.files.length >= r.fileCount) return json(409, { error: 'All images for this request are already uploaded.' });

  const n = r.files.length + 1;
  const name = String(q.name || 'image').replace(/[^\w.\- ]+/g, '').slice(0, 80) || 'image';
  const key = `${id}/${n}`;
  await s.uploads.set(key, body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength), { metadata: { name, type, size: body.length } });
  r.files.push({ key, name, type, size: body.length });
  await s.requests.setJSON(id, r);
  return json(200, { ok: true, uploaded: r.files.length });
};
