// Step 1 of a client's request: saves their plan and description, and returns a short-lived token
// that lets this visitor upload their images to this one request.
const crypto = require('crypto');
const { json } = require('../lib/util');
const { stores, log } = require('../lib/store');
const { uploadToken, sameOrigin } = require('../lib/admin');

const PLANS = { basic: 'Keyturn Basic', plus: 'Keyturn Plus', premium: 'Keyturn Premium' };
const MAX_FILES = 12;
const LIMITS = { name: 80, business: 120, email: 160, phone: 40, domain: 120, about: 1500, wants: 3000, style: 600, examples: 600 };

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  if (!sameOrigin(event)) return json(403, { error: 'Requests must come from this site.' });
  if (!process.env.SESSION_SECRET) return json(503, { error: 'Requests aren\'t switched on yet. The site owner needs to finish setup.' });

  let b;
  try { b = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Something went wrong reading the form. Please try again.' }); }
  if (b.website) return json(200, { id: 'ok', token: 'ok', expires: 0 }); // hidden field only bots fill in

  const f = {};
  for (const k of Object.keys(LIMITS)) f[k] = String(b[k] || '').trim().slice(0, LIMITS[k]);
  const plan = String(b.plan || '');
  const missing = [];
  if (!PLANS[plan]) missing.push('a plan');
  if (!f.name) missing.push('your name');
  if (!f.business) missing.push('your business name');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email)) missing.push('a valid email address');
  if (!f.about) missing.push('what your business does');
  if (!f.wants) missing.push('what the website should include');
  if (missing.length) return json(400, { error: 'Please add ' + missing.join(', ') + '.' });
  const fileCount = Math.max(0, Math.min(MAX_FILES, parseInt(b.fileCount, 10) || 0));

  const s = stores(event);
  // At most 5 requests an hour from one visitor
  const ip = (event.headers['x-nf-client-connection-ip'] || event.headers['client-ip'] || 'unknown').replace(/[^0-9a-fA-F:.]/g, '');
  const hourKey = ip + '-' + new Date().toISOString().slice(0, 13);
  const count = (await s.limits.get(hourKey, { type: 'json' })) || 0;
  if (count >= 5) return json(429, { error: 'Too many requests from this connection. Please try again in an hour.' });
  await s.limits.setJSON(hourKey, count + 1);

  const id = crypto.randomBytes(9).toString('base64').replace(/[^A-Za-z0-9]/g, '').slice(0, 10) + Date.now().toString(36).slice(-4);
  const expires = Date.now() + 2 * 3600 * 1000;
  const record = {
    id, plan, planName: PLANS[plan], ...f, fileCount, files: [],
    status: 'uploading', createdAt: new Date().toISOString(), notes: '',
  };
  await s.requests.setJSON(id, record);
  await log(s, 'visitor', 'Started a request', `${PLANS[plan]} · ${f.business}`);
  return json(200, { id, token: uploadToken(id, expires), expires });
};
