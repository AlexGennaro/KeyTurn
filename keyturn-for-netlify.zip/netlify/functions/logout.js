// Disconnects the Netlify account from this browser.
const { cookie } = require('../lib/util');

exports.handler = async () => ({
  statusCode: 302,
  headers: { Location: '/#launch' },
  multiValueHeaders: { 'Set-Cookie': [cookie('nf_token', '', 0)] },
  body: '',
});
