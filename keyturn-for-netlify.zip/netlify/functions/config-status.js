// Tells the pages which parts of Keyturn are switched on.
const { isConfigured } = require('../lib/util');
const { adminConfigured } = require('../lib/admin');

exports.handler = async () => ({
  statusCode: 200,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify({ configured: isConfigured(), requests: !!process.env.SESSION_SECRET, admin: adminConfigured(), email: !!process.env.RESEND_API_KEY }),
});
