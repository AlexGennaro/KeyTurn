// Admin sign-in: password plus a 6-digit authenticator code, or a one-time recovery code.
// After 5 wrong tries, sign-in pauses for 15 minutes. Every attempt is written to the activity log.
const { json } = require('../lib/util');
const { stores, log } = require('../lib/store');
const { adminConfigured, checkPassword, totpStep, recoveryHash, sessionCookie, sameOrigin } = require('../lib/admin');

const MAX_FAILS = 5, PAUSE_MS = 15 * 60 * 1000;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  if (!sameOrigin(event)) return json(403, { error: 'Sign in from this site.' });
  if (!adminConfigured()) return json(503, { error: 'Admin sign-in isn\'t set up yet. Open /admin/setup.html.' });
  let b;
  try { b = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Something went wrong. Try again.' }); }

  const s = stores(event);
  const lock = (await s.admin.get('lock', { type: 'json' })) || { fails: 0, until: 0 };
  if (lock.until > Date.now()) {
    const mins = Math.ceil((lock.until - Date.now()) / 60000);
    return json(429, { error: `Too many wrong attempts. Try again in ${mins} minute${mins === 1 ? '' : 's'}.` });
  }

  const fail = async (why) => {
    lock.fails = (lock.fails || 0) + 1;
    if (lock.fails >= MAX_FAILS) { lock.until = Date.now() + PAUSE_MS; lock.fails = 0; }
    await s.admin.setJSON('lock', lock);
    await log(s, 'someone', 'Admin sign-in failed', why);
    return json(401, { error: lock.until > Date.now() ? 'Too many wrong attempts. Sign-in is paused for 15 minutes.' : 'That password or code isn\'t right.' });
  };

  if (!checkPassword(b.password)) return fail('wrong password');

  if (b.recovery) {
    const h = recoveryHash(b.recovery);
    const used = (await s.admin.get('usedRecovery', { type: 'json' })) || [];
    if (!h || used.includes(h)) return fail('bad or used recovery code');
    used.push(h);
    await s.admin.setJSON('usedRecovery', used);
    await log(s, 'admin', 'Signed in with a recovery code', `${10 - used.length} recovery code(s) left at most`);
  } else {
    const step = totpStep(b.code);
    const last = (await s.admin.get('lastStep', { type: 'json' })) || 0;
    if (step < 0 || step <= last) return fail(step < 0 ? 'wrong authenticator code' : 'authenticator code reused');
    await s.admin.setJSON('lastStep', step);
    await log(s, 'admin', 'Signed in', '');
  }
  await s.admin.setJSON('lock', { fails: 0, until: 0 });
  return json(200, { ok: true }, { multiValueHeaders: { 'Set-Cookie': [sessionCookie()] } });
};
