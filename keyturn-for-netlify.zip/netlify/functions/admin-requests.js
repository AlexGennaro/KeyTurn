// Admin only. GET: list all requests (newest first), or one request with ?id=.
// POST {id, status?, notes?}: update a request's status or private notes. GET ?activity=1: the activity log.
const { json } = require('../lib/util');
const { stores, log } = require('../lib/store');
const { isAdmin, sameOrigin } = require('../lib/admin');
const { ensureTracker, recordStatus, trackUrl, sendClientEmail, clientEmailsOn } = require('../lib/track');

const STATUSES = ['new', 'building', 'preview_sent', 'paid', 'live', 'closed'];

exports.handler = async (event) => {
  if (!isAdmin(event)) return json(401, { error: 'signin' });
  const s = stores(event);
  const q = event.queryStringParameters || {};

  if (event.httpMethod === 'GET' && q.activity) {
    const { blobs } = await s.activity.list();
    const keys = blobs.map((b) => b.key).sort().reverse().slice(0, 100);
    const items = await Promise.all(keys.map((k) => s.activity.get(k, { type: 'json' })));
    return json(200, { activity: items.filter(Boolean) });
  }
  if (event.httpMethod === 'GET' && q.id) {
    const r = await s.requests.get(String(q.id), { type: 'json' });
    if (!r) return json(404, { error: 'Request not found.' });
    if (!r.trackToken) { await ensureTracker(s, r); await s.requests.setJSON(r.id, r); } // older requests get a tracker too
    return json(200, { request: r, trackUrl: trackUrl(event, r.trackToken), clientEmails: clientEmailsOn() });
  }
  if (event.httpMethod === 'GET') {
    const { blobs } = await s.requests.list();
    const all = await Promise.all(blobs.map((b) => s.requests.get(b.key, { type: 'json' })));
    const list = all.filter((r) => r && r.status !== 'uploading')
      .sort((a, b) => (b.submittedAt || b.createdAt).localeCompare(a.submittedAt || a.createdAt))
      .map(({ id, plan, planName, name, business, email, status, submittedAt, createdAt, files }) => ({ id, plan, planName, name, business, email, status, submittedAt: submittedAt || createdAt, images: (files || []).length }));
    return json(200, { requests: list });
  }
  if (event.httpMethod === 'POST') {
    if (!sameOrigin(event)) return json(403, { error: 'Changes must come from this site.' });
    let b;
    try { b = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Bad request.' }); }
    const r = await s.requests.get(String(b.id || ''), { type: 'json' });
    if (!r) return json(404, { error: 'Request not found.' });
    if (b.previewUrl != null) {
      const u = String(b.previewUrl).trim();
      if (u && !/^https:\/\/[^\s]+$/i.test(u)) return json(400, { error: 'The preview link must start with https://' });
      r.previewUrl = u.slice(0, 500);
    }
    let changed = false;
    if (b.status != null) {
      if (!STATUSES.includes(b.status)) return json(400, { error: 'Unknown status.' });
      if (b.status === 'preview_sent' && !r.previewUrl) return json(400, { error: 'Add the client\'s preview link first, so the email and tracker can link to it.' });
      if (b.status !== r.status) { changed = true; await log(s, 'admin', 'Changed request status', `${r.business}: ${r.status} → ${b.status}`); }
      r.status = b.status;
      recordStatus(r, b.status);
    }
    if (b.notes != null) r.notes = String(b.notes).slice(0, 5000);
    await ensureTracker(s, r);
    r.updatedAt = new Date().toISOString();
    await s.requests.setJSON(r.id, r);
    let email = null; // the client is emailed when their website reaches "Preview ready" or "Live"
    if (changed && b.notify !== false && (r.status === 'preview_sent' || r.status === 'live')) {
      email = await sendClientEmail(r.status, r, event);
      await log(s, 'server', email.ok ? 'Status email sent to client' : 'Status email not sent', email.ok ? `${r.email}: ${r.status}` : (email.skipped || email.error));
    }
    return json(200, { request: r, trackUrl: trackUrl(event, r.trackToken), email });
  }
  return json(405, { error: 'Use GET or POST.' });
};
