// Signs the admin out by deleting the session cookie.
const { json } = require('../lib/util');
const { clearSessionCookie } = require('../lib/admin');

exports.handler = async () => json(200, { ok: true }, { multiValueHeaders: { 'Set-Cookie': [clearSessionCookie()] } });
