// Puts the website into the connected (client's) Netlify account.
// - If a site in this account already uses the domain, it updates that site (no duplicates).
// - Otherwise it creates a new site, uploads index.html, and attaches the domain.
const crypto = require('crypto');
const { json, getToken, netlify, cleanDomain, DOMAIN_RE, NETLIFY_APEX_IP } = require('../lib/util');
const { isAdmin } = require('../lib/admin');

const MAX_BYTES = 4.5 * 1024 * 1024; // Netlify Functions accept request bodies up to about 6 MB.

async function findSiteForDomain(token, domain) {
  for (let page = 1; page <= 5; page++) {
    const sites = await netlify(token, `/sites?filter=all&per_page=100&page=${page}`);
    const hit = sites.find((s) =>
      s.custom_domain === domain ||
      s.custom_domain === `www.${domain}` ||
      (s.domain_aliases || []).includes(domain) ||
      (s.domain_aliases || []).includes(`www.${domain}`));
    if (hit) return hit;
    if (sites.length < 100) return null;
  }
  return null;
}

function friendlyDomainError(message, domain) {
  if (/already|in use|taken|exists|managed/i.test(message)) {
    return `${domain} is already connected to a different Netlify account. The owner needs to remove it there first (Domain management → remove domain), then launch again. The site itself is live at its preview address.`;
  }
  return `The site is live at its preview address, but Netlify couldn't attach ${domain} (${message}). Try launching again in a minute.`;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  // Until paid launch links are added, only a signed-in Keyturn admin can launch. Nobody can launch for free.
  if (!isAdmin(event)) return json(403, { error: 'Launching is done through your Keyturn launch link. Pick a plan to get started.' });

  const token = getToken(event);
  if (!token) return json(401, { error: 'signin' });

  let payload;
  try { payload = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Something went wrong reading the request. Refresh and try again.' }); }

  const html = typeof payload.html === 'string' ? payload.html : '';
  const domain = cleanDomain(payload.domain);

  if (!html.trim()) return json(400, { error: 'Add the website file first.' });
  if (!/<html|<body|<!doctype/i.test(html)) return json(400, { error: "That file doesn't look like a web page. Choose the site's index.html." });
  if (Buffer.byteLength(html) > MAX_BYTES) return json(400, { error: 'That file is over 4.5 MB. Shrink the images and try again.' });
  if (!DOMAIN_RE.test(domain)) return json(400, { error: `"${payload.domain}" isn't a domain. Use the format yourbusiness.com.` });

  try {
    // 1. Reuse the site already tied to this domain, or create a new one.
    let site = await findSiteForDomain(token, domain);
    const updated = !!site;
    if (!site) {
      const base = domain.split('.')[0].replace(/[^a-z0-9-]/g, '').slice(0, 40) || 'site';
      site = await netlify(token, '/sites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: `${base}-${crypto.randomBytes(2).toString('hex')}` }),
      });
    }

    // 2. Deploy index.html with Netlify's file-digest method.
    const file = Buffer.from(html, 'utf8');
    const sha1 = crypto.createHash('sha1').update(file).digest('hex');
    const deploy = await netlify(token, `/sites/${site.id}/deploys`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ files: { '/index.html': sha1 } }),
    });
    if ((deploy.required || []).includes(sha1)) {
      await netlify(token, `/deploys/${deploy.id}/files/index.html`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: file,
      });
    }

    // 3. Attach the domain (new sites only; updated sites already have it).
    let domainError = null;
    if (!updated) {
      try {
        await netlify(token, `/sites/${site.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ custom_domain: domain, domain_aliases: [`www.${domain}`] }),
        });
      } catch (e) {
        domainError = friendlyDomainError(e.message, domain);
      }
    }

    return json(200, {
      updated,
      siteId: site.id,
      deployId: deploy.id,
      previewUrl: site.ssl_url || `https://${site.default_domain}`,
      adminUrl: site.admin_url,
      domain,
      domainError,
      records: [
        { type: 'A', name: '@', value: NETLIFY_APEX_IP },
        { type: 'CNAME', name: 'www', value: site.default_domain },
      ],
    });
  } catch (e) {
    if (e.status === 401) return json(401, { error: 'signin' });
    return json(502, { error: `Netlify had a problem (${e.message}). Nothing was lost; press Launch to try again.` });
  }
};
