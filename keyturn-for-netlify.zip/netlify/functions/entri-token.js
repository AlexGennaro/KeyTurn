// Gives the page a short-lived Entri token so the client can press "Connect my domain",
// sign in at their domain company in Entri's window, and approve the two settings automatically.
// Needs ENTRI_APPLICATION_ID and ENTRI_SECRET (from your Entri dashboard).
// For now only a signed-in admin can start it; paid launch links will be allowed in Phase 2.
const { json } = require('../lib/util');
const { isAdmin, sameOrigin } = require('../lib/admin');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  if (!sameOrigin(event)) return json(403, { error: 'Requests must come from this site.' });
  if (!isAdmin(event)) return json(403, { error: 'Connecting a domain starts from your launch link.' });
  const applicationId = process.env.ENTRI_APPLICATION_ID, secret = process.env.ENTRI_SECRET;
  if (!applicationId || !secret) return json(503, { error: 'manual' }); // not set up: the page shows the copy-paste screen instead

  const res = await fetch('https://api.goentri.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ applicationId, secret }),
  });
  const d = await res.json().catch(() => ({}));
  if (!res.ok || !d.auth_token) return json(502, { error: 'manual' });
  return json(200, { applicationId, token: d.auth_token });
};
