# Keyturn

A complete website: the homepage explains the service, and the launcher is built into it (the "Launch a website" buttons open it). When the site runs without its Netlify functions, such as in a preview, the launcher switches to a clearly labeled walkthrough instead of showing errors. Drop in a client's `index.html`, type their domain, press **Launch website**. The site goes into the client's own Netlify account, attached to their domain. You never handle their passwords, and they own everything.

## Setup (one time, about 20 minutes, no commands)

Netlify's drag-and-drop page can't run the launcher's behind-the-scenes functions, so the launcher goes on Netlify through GitHub instead. Everything below is clicking in a browser.

1. **Upload the folder to GitHub.**
   Create a free account at github.com, then choose **New repository** (name it `keyturn`, set it to Private, and create it). On the new repository's page, click **uploading an existing file**, drag in everything inside the unzipped `keyturn` folder, and press **Commit changes**.

2. **Put it on Netlify.**
   In Netlify, choose **Add new site → Import an existing project → GitHub**, approve access, and pick `keyturn`. Leave the settings as they are (they're read from `netlify.toml`) and press **Deploy**. You'll get an address like `https://something.netlify.app`.

3. **Open that address and press Launch a website.**
   The first time you press Launch, the launcher sends you to its built-in setup page (also at `/setup.html`). It shows your exact values with copy buttons and walks you through the last three clicks: creating a Netlify sign-in app, adding two settings, and redeploying once.

4. **Change the name (optional).**
   "Keyturn" appears throughout `public/index.html`. Edit them on GitHub with the pencil icon and commit; Netlify updates the site automatically.

5. **Use your own domain for Keyturn (optional).** In the Keyturn site's Netlify dashboard, open *Domain management* and add a domain you own. Afterward, revisit `/setup.html` and update the Redirect URI in your Netlify OAuth app to match the new address.

6. **Test it with a domain you own** before using it with a client.

## Requests and admin (new)

"Pick a plan" on the homepage opens a request form. Clients choose Basic, Plus or Premium, describe their business and upload their logo and photos. Each request is saved privately (Netlify Blobs, included with Netlify) and emailed to **TryKeyTurn@gmail.com**. You see everything in the admin page at **/admin**.

The old "drop any file and launch" launcher is switched off for the public. Only a signed-in admin can launch, until paid launch links are added.

### One-time setup (about 15 minutes)

1. **Upload this folder to GitHub** as before. Netlify redeploys automatically.
2. **Admin sign-in:** open `https://YOUR-SITE.netlify.app/admin/setup.html`. Choose a password, add the key to your authenticator app, save your recovery codes, and copy the four values it gives you: `ADMIN_PASSWORD_HASH`, `ADMIN_TOTP_SECRET`, `ADMIN_RECOVERY_HASHES` and `SESSION_SECRET`.
3. **Email notifications:** create a free account at **resend.com** using **TryKeyTurn@gmail.com**, then create an API key. Until you verify your own domain in Resend, it can only email the address you signed up with, which is all this needs.
4. **Add the settings in Netlify:** your site → **Site configuration → Environment variables → Add a variable**. Add the four admin values plus `RESEND_API_KEY`. Tick "Contains secret values" where offered.
5. **Redeploy:** Deploys → Trigger deploy → Deploy site.
6. **Test it:** open your site, press **Pick a plan**, send a test request with a photo, check TryKeyTurn@gmail.com, then sign in at `/admin`.

| Setting | What it's for |
|---|---|
| `ADMIN_PASSWORD_HASH` | Your password, scrambled. The real password is never stored. |
| `ADMIN_TOTP_SECRET` | Connects your authenticator app. |
| `ADMIN_RECOVERY_HASHES` | Your 10 one-time recovery codes, scrambled. |
| `SESSION_SECRET` | Signs your admin sign-in and the request form's upload links. |
| `RESEND_API_KEY` | Sends the "new request" emails. |
| `NOTIFY_EMAIL` (optional) | Where new requests are emailed. Defaults to TryKeyTurn@gmail.com. |

Sign-in pauses for 15 minutes after 5 wrong attempts. Every sign-in, failed attempt and request is listed under **Activity** in the admin page. Lost your phone? Sign in with your password and one recovery code, then run the setup page again and replace the values in Netlify.

### One-click domain connection (Entri)

On launch day, clients press **Connect my domain**. A window opens from their domain company (GoDaddy, Namecheap and most others), they sign in and press **Approve**, and the two settings are added for them. Nothing to copy or paste. This uses **Entri** (entri.com), a paid service.

1. Create an account at **entri.com** and choose a plan.
2. In the Entri dashboard, copy your **Application ID** and **Secret**.
3. In Netlify, add two environment variables: `ENTRI_APPLICATION_ID` and `ENTRI_SECRET`, then redeploy.

Without these, Keyturn falls back to showing the two settings with copy buttons. The button and its code are in `public/js/connect-domain.js` and `netlify/functions/entri-token.js`. Clients will use it from their paid launch link (Phase 2).

### Order tracker and client emails

Every request gets a private tracking link (`/track/?t=…`). The client sees it on the thank-you screen and in their confirmation email, and you can copy it from the request in `/admin`. It shows: Request received → Designer building it → Preview ready → Paid → Live, with dates, and updates the moment you change the status.

Clients are emailed automatically:
- **"We got your request"** with their tracking link, when they send the form.
- **"Your preview is ready"** with a button to their preview, when you set the status to **Preview sent**. Add their preview link in the request first.
- **"You're live"** when you set the status to **Live**.

To switch client emails on, verify your own domain in Resend (resend.com → Domains), then add these Netlify environment variables and redeploy:

| Setting | Example | What it's for |
|---|---|---|
| `CLIENT_EMAILS` | `on` | Turns on emails to clients |
| `MAIL_FROM` | `Keyturn <hello@yourdomain.com>` | Who the emails come from (must be your verified domain) |
| `REPLY_TO` (optional) | `TryKeyTurn@gmail.com` | Where client replies go. Defaults to NOTIFY_EMAIL |
| `SITE_URL` (optional) | `https://yourdomain.com` | The address used in tracking links. Defaults to the site's own address |

Until then, everything else works: the tracker updates, and the admin page reminds you to send the client their link yourself.

## Using it with a client

1. Press **Launch a website**, drop their `index.html` into the box (a preview appears) and type their domain.
2. Press **Launch website**. If the owner isn't signed in, Netlify opens so they can sign up or sign in and click **Authorize**. The launch then continues by itself.
3. Add the two DNS records shown at their domain company (they sign in, or grant you delegate access).
4. Leave the page open. It checks every 30 seconds and tells you when the domain is connected, or what it's still pointing to.
5. If the site has forms, follow the forms note on the final screen.
6. Click **Disconnect** (top right) when you're done.

**Updating a client's site later:** sign into their account the same way, drop in the new file, enter the same domain, and press Launch. The launcher finds their existing site and updates it instead of creating a new one. No DNS changes needed.

## Make the Earth photo-realistic (recommended)

The globe uses real satellite photos when you add them. NASA's images are public domain, so they're free to use on a commercial site.

1. Go to **visibleearth.nasa.gov** and download these three (choose a large size, around 4096 x 2048 or 5400 x 2700):
   - **Blue Marble** (the true-color Earth; the "topography and bathymetry" version looks best). Save it as `day.jpg`.
   - **Black Marble / Earth at Night** (the color city-lights map). Save it as `night.jpg`.
   - **Blue Marble: Clouds** (white clouds on black). Save it as `clouds.jpg`.
2. Put all three in the `public/earth/` folder (on GitHub: open that folder, choose **Add file > Upload files**).
3. Netlify redeploys automatically. Reload the site and the realistic Earth appears, with city lights on the night side.

The footer automatically adds the "Earth imagery: NASA Visible Earth" credit when the photos are in use. Any missing image falls back to the built-in drawn version of that layer.

## Good to know

- **The Earth, zoom, and rocket** are drawn with the browser's built-in WebGL, so there's no code library to load. Without the NASA photos, the continents are a simplified hand-drawn map; the globe paints itself in about a second while the door animation plays. On devices without WebGL, the site shows a starry space background instead. Visitors who turn off animations get a still Earth and no zoom or rocket.

- The A record IP (`75.2.60.5`) is Netlify's address for external DNS. Confirm it in Netlify's "Configure external DNS" docs; if it ever changes, edit `NETLIFY_APEX_IP` in `netlify/lib/util.js`.
- Files up to about 4.5 MB are supported.
- The launcher handles a main domain plus `www`. Subdomains like `shop.example.com` are best set up by hand in the client's Netlify dashboard.
- If a domain is already attached to a different Netlify account, the launcher explains how to free it up.
- A client's Netlify access is kept only in a secure browser cookie for 8 hours, and **Disconnect** removes it immediately.
