// "Connect my domain": opens Entri's window so the client signs in at their domain company
// and approves Keyturn's two settings, with nothing to copy or paste.
//
//   const result = await KeyturnConnectDomain.open({ domain: 'joescafe.com', siteHost: 'joescafe-a1b2.netlify.app' });
//   result.status is 'connected' (done, automatically or by Entri's guided steps),
//                    'closed'    (the client closed the window before finishing), or
//                    'manual'    (Entri isn't available, so show the copy-paste screen instead).
(function () {
  const APEX_IP = '75.2.60.5'; // Netlify's address for a main domain (see netlify/lib/util.js)
  let loading = null;

  function loadEntri() {
    if (window.entri) return Promise.resolve();
    if (!loading) loading = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.goentri.com/entri.js'; s.async = true;
      s.onload = () => (window.entri ? res() : rej(new Error('Entri did not load')));
      s.onerror = () => rej(new Error('Entri did not load'));
      document.head.appendChild(s);
    });
    return loading;
  }

  async function open({ domain, siteHost }) {
    let cfg;
    try {
      const r = await fetch('/.netlify/functions/entri-token', { method: 'POST', credentials: 'same-origin' });
      if (!r.ok) return { status: 'manual' };
      cfg = await r.json();
      await loadEntri();
    } catch (e) { return { status: 'manual' }; }

    return new Promise((resolve) => {
      let finished = false;
      const cleanup = () => { window.removeEventListener('onSuccess', onSuccess); window.removeEventListener('onEntriClose', onClose); };
      const onSuccess = (e) => { finished = true; cleanup(); resolve({ status: 'connected', setupType: e.detail && e.detail.setupType, provider: e.detail && e.detail.provider }); };
      const onClose = (e) => {
        if (finished) return;
        cleanup();
        const d = e.detail || {};
        const done = d.success || d.lastStatus === 'FINISHED_SUCCESSFULLY' || d.lastStatus === 'FINISHED_SUCCESSFULLY_MANUAL';
        resolve({ status: done ? 'connected' : 'closed', setupType: d.setupType, provider: d.provider });
      };
      window.addEventListener('onSuccess', onSuccess, false);
      window.addEventListener('onEntriClose', onClose, false);
      const config = {
        applicationId: cfg.applicationId,
        token: cfg.token,
        prefilledDomain: domain,
        dnsRecords: [
          { type: 'A', host: '@', value: APEX_IP, ttl: 300 },
          { type: 'CNAME', host: 'www', value: siteHost, ttl: 300 },
        ],
      };
      // connectDomain is Entri's "connect a domain you own" window (showEntri is its older name)
      try { (window.entri.connectDomain || window.entri.showEntri).call(window.entri, config); }
      catch (e) { cleanup(); resolve({ status: 'manual' }); }
    });
  }

  window.KeyturnConnectDomain = { open };
})();
